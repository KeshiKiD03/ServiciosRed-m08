### ASIX M06-ASO
#### Christian Manalo Mañibo - isx9565961


###### Curs 2020-2021 
Repositori per guardar tots els projectes que s'ha fet a l'Escola Del Treball, segon curs de cicle superior ASIX.
