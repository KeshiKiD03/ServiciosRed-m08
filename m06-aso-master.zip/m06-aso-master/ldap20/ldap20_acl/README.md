# M06-ASO LDAP SERVER BASE
## Escola Del Treball
### 2HISX 2020-2021
### Christian Manalo Mañibo

- ldap20:acl Imatge ldap20:editat per fer proves acl.

**Interactiu**

`$ docker run --rm --name ldap.edt.org -h ldap.edt.org --net 2hisx -p 389:389  -it chriswar/ldap20:acl /bin/bash `

