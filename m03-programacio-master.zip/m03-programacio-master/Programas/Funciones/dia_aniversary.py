#!/usr/bin/python3
#-*- coding: utf-8-*-

# Escola del treball de Barcelona
# ASIX 2019-2020

# Christian Manalo
# isx9565961
# 19/2/2020

# Versió: 1
# Descripció:
# Jocs de prova: avui (19/02/2020)
# DIA          MES           DIAS QUE FALTEN
# 19            2                  0
# 17            2                 364
# 28            2                  9

import sys
import dates

def dias_aniversari(d,m):
	'''
	input: int int
	output: int
	'''
	# saber data actual
	DIA_ACTUAL = 19
	MES_ACTUAL = 2
	ANY_ACTUAL = 2020

	# Crear data actual

	# crear aniversari any actual

	# si l'aniversari es anterior a la data actual

		# busquem aniversari seguent
	
	# contem els dies des d'avui a l'aniversari


