#!/usr/bin/python3
#-*- coding: utf-8-*- 

# Escola del treball de Barcelona 
# ASIX 2019-2020 

# Christian Manalo 
# isx9565961 
# 22/10/19

# Versió: 1
# Descripció: Introduir 1 número decimal i mostrar el número arrodonit.
# Especificacions d'Entrada: 1 número float 

# Jocs de prova: 
#     ENTRADA               SALIDA
#      5.23                   5
#      6.79                   7

# Introduir el número
num = float(input("Introduir el número: "))

# Arrodonir el número
print(round(num))
