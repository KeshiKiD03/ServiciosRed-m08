#!/usr/bin/python3
#-*- coding: utf-8-*-

# Escola del treball de Barcelona
# ASIX 2019-2020

# Christian Manalo
# isx9565961
# 28/3/2020


# 8.  

#De moment, no passa res si suposem que l'entrada és una única línia
#quan treballem amb fitxers aprendrem a llegir línia a línia

#Versió 1 per a comptar les vocals

#Per a la versió 2: vull comptar 'abcd'. Què he de modificar?

#Per a la versió 3 (o exercici9: comptar certes paraules). L'algoritme
#és pràcticament el mateix. Em serveixen les mateixes funcions?


import sys
def cerca_sequencial(sequencia, element):
	'''
	Funció que ens diu si un caràcter està o no en una cadena
	Entrada: cadena, caràcter
	Sortida: int (la posició que ocupa aquest caràcter, -1 si no hi és
	'''
	

def frequencia(sequencia):
	'''
	input: cadena de caràcters
	output: llista d'enters, on a cada posició hi ha la quantitat dels elements buscats
	'''
	#creem una llista tan llarga com les vocals
	
	#per cada lletra del text
	
		#si és una vocal
		
			#busquem quina és la seva posició
			
			#en comptem una més
			
	
def histograma(freqs, capsalera):
	'''
	input: llista d'enters
	output: res (void)
	'''
	
	

VOCALS = 'aeiou'

#Calculem les frequencies
text = input()
l_frequencies = frequencia(text)


#Mostrem l'histograma 
histograma(l_frequencies, VOCALS)