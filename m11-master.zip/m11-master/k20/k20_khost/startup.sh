#! /bin/bash


/opt/docker/install.sh $$ echo " OK Install "
/bin/bash
