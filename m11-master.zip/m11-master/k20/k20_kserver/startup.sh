#! /bin/bash


/opt/docker/install.sh $$ echo " OK Install "
/sbin/krb5kdc
/sbin/kadmind -nofork
