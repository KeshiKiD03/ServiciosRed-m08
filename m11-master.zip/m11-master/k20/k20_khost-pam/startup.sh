#! /bin/bash

/opt/docker/install.sh && echo "Ok install"
/bin/bash
