### Exercicis dispositius de disc

**_Ull viu! Vigileu i aneu amb molt de compte amb els següents exercicis_**

##### Exercici 1.

Com a root executeu `fdisk` (de manera interactiva) per a manipular el vostre
disc dur. Quina ordre heu d'executar?

>`fdisk /dev/sda `

Un cop dintre, recordem que ```m``` (*man*) ens mostra les diferents opcions de
que disposem. Quina opció ens mostra l'arquitectura del disc dur? (És a dir, el
disseny de les particions)

>`Opció p (*print*)`

Apunteu les particions que teniu (**per no eliminar-les**). Amb quina opció es
pot crear una partició?

>`Opció n (*new*)`

Creeu-la (de tipus primària i de mida 1000 MB). Amb quina opció es desen els
canvis a la taula de particions?

>`Opció n (*new*)`
>`Opció p (*Primary*)`
>`Seleccionar la partició 2`
>`I posem la mida del disc`
>`Es desen amb w`

Deseu els canvis i llegiu el missatge de sortida actuant en conseqüència. Ens
servirà d'ajuda esbrinar quines particions tenim disponibles, utilitzant el que
hem après al tema anterior. Qualsevol ordre de les següents ens servirà:

```
ls /dev/sda*
cat /proc/partitions
ls /sys/block/sda/sda*
```

##### Exercici 2.

Ara que acabem de crear una partició la volem utilitzar. Per a això muntarem la
nova partició a un directori, per exemple a `/mnt/nova_particio`.

>`mount /dev/sda2 /mnt/novaparticio`
> No deixa muntar per el tipus de sistema de fitxers.

##### Exercici 3.

Cerqueu l'executable `mkfs`. És a dir, doneu la trajectòria on es troba el
binari. Creeu el sistema de fitxers de tipus *ext4* a la partició que havíeu
creat abans. Intenteu ara muntar el dispositiu i crear algun fitxer a dintre.

>`mkfs.ext4 /dev/sda2`

##### Exercici 4.

Quina opció de l'ordre mount *llegeix/executa* les línies del fitxer
`/etc/fstab` (a excepció de les línies que tinguin l'opció *noauto*)?

>`mount -a`

##### Exercici 5.

El fitxer */etc/fstab* especifica les unitats que volem muntar en l'arrencada
del sistema mitjançant línies. Cadascuna d'aquestes línies està formada per sis
camps. Quin d'aquest camps ens dóna les opcions de muntatge?

>`El segon camp`

Quina opció de muntatge permet muntar un dispositiu a un usuari ordinari?
>`Con la opcion -noauto`

Si volem que un usuari qualsevol el pugui muntar i un altre, diferent d'aquest,
el pugui desmuntar, quina és l'opció que ens permet fer això?
>`Opcion -user`

Quin camp ens indica l'ordre en que es fan els xequejos dels dispositius a
muntar?
>`El quart camp`

Si estic segur que un cert dispositiu no tindrà problemes(¿?), com puc evitar
que es xequegi aquest dispositiu?
>`mount -a`

##### Exercici 6.

**_Atenció amb aquest perillòs exercici. Feu-lo en parelles 2 persones i 1 pc._**

Comenteu totes les línies del fitxer /etc/fstab. Reinicieu la màquina. Potser
heu de fer un *scape* perquè es mostrin els missatges. Si després de fer
aquests passos, ja no sabeu que fer demaneu la pista número 1. 

Un cop resolt aquest problema si després d'intentar restaurar el fitxer
`/etc/fstab` no aconseguiu avançar demaneu la pista número 2.

##### OBSERVACIÓ:

Existeix una distribució GNU/Linux que no és per a usuaris novells però que la
seva documentació és d'una gran qualitat. Sempre que busqueu algun tipus
d'informació relativa a GNU/Linux tingueu-la en compte: archlinux.

En aquest cas us pot ser d'ajuda [el document que han fet relatiu a
/etc/fstab](https://wiki.archlinux.org/index.php/fstab)
